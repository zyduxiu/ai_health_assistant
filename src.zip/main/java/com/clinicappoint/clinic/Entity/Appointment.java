package com.clinicappoint.clinic.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;

@Entity
@Table(name="appointment")
@Data
public class Appointment {
    @Id
    private int appointmentkey;

    private int minuteIndex;

    private String name;
    private String phonenumber;
    private String type;
    private String membership;
    private String appointmentStartTime;
    private String appointmentDate;
    private int appointmentStartHourindex;
    private int appointmentStartMinutesindex;
    private int appointmentEndHourindex;
    private int appointmentEndMinutesindex;
    private String appointmentEndTime;
    private String attribute;
    private int appointmentcost;
    @OneToOne(targetEntity = DoctorEntity.class,mappedBy = "appointment",cascade = CascadeType.ALL)
    private DoctorEntity doctorName;
    private int hourindex;
    private String date;

}
