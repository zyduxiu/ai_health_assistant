package com.clinicappoint.clinic.Entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Table(name="membertable")
@Data

public class Member {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int key;
    private String name;
    private String gender;
    private int age;
    private String amount;
    private boolean isMember;
    @OneToMany(mappedBy = "member", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<membercard> cards;

}
