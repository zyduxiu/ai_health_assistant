package com.clinicappoint.clinic.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;

@Entity
@Table(name="membercard")
@Data
public class membercard {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int cardid;
    private String cardType;
    private int cardBalance;
    private int cardNumber;
    private String cardDiscount;
    @ManyToOne
    @JsonIgnore
    @ToString.Exclude
    private Member member;

}
