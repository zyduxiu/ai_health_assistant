package com.clinicappoint.clinic.Controller;

import com.clinicappoint.clinic.Entity.UserAuth;
import com.clinicappoint.clinic.Service.UserAuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
@CrossOrigin
@RestController
public class LoginController {
    @Autowired
    UserAuthService userAuthService;
    @CrossOrigin
    @GetMapping("/login")
    public UserAuth checkLogin(String username, String password){
        return userAuthService.getLogininformation(username,password);
    }
}
