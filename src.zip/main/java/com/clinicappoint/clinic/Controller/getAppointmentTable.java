//package com.clinicappoint.clinic.Controller;
//
//import com.clinicappoint.clinic.Service.AppointmentTableService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//@CrossOrigin
//@RestController
//public class getAppointmentTable {
//    @Autowired
//    AppointmentTableService appointmentTableService;
//    @CrossOrigin
//    @GetMapping("/test")
//    public AppointmentTable getAppointmenttable(String date){
//        return appointmentTableService.getAppointmentTableByDate(date);
//    }
//}
