package com.clinicappoint.clinic.ServiceImp;

import com.clinicappoint.clinic.Entity.Appointment;
import com.clinicappoint.clinic.Repository.AppointmentRepository;
import com.clinicappoint.clinic.Service.AppointmentTableService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AppointmentTableServiceImpl implements AppointmentTableService {
    @Autowired
    AppointmentRepository appointmentRepository;

    @Override
    public List<Appointment> getAppointmentTableByDate(String date) {
        return appointmentRepository.findAll();
    }

    @Override
    public void postAppointment(String date,String doctorName,int Hourindex,int Minuteindex,String attribute){
        Appointment appointment=new Appointment();
        appointment.setAppointmentDate(date);
        appointment.setHourindex(Hourindex);
        appointment.setMinuteIndex(Minuteindex);
        appointment.setAttribute(attribute);
        appointmentRepository.save(appointment);
        return;
    }

}
