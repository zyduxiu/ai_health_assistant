package com.clinicappoint.clinic.Service;

import com.clinicappoint.clinic.Entity.Appointment;

import java.util.List;

public interface AppointmentTableService {
    public List<Appointment> getAppointmentTableByDate(String date);

    public void postAppointment(String date,String doctorName,int Hourindex,int Minuteindex,String attribute);
}
