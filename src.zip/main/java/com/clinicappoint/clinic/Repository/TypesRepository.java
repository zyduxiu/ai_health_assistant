package com.clinicappoint.clinic.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.clinicappoint.clinic.Entity.types;
public interface TypesRepository extends JpaRepository<types,Integer> {
}
