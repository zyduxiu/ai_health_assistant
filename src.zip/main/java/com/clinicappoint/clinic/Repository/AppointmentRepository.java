package com.clinicappoint.clinic.Repository;

import com.clinicappoint.clinic.Entity.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AppointmentRepository extends JpaRepository<Appointment,Integer> {

}
