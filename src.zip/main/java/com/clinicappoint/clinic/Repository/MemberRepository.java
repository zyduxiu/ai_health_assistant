package com.clinicappoint.clinic.Repository;

import com.clinicappoint.clinic.Entity.Member;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MemberRepository extends JpaRepository<Member,Integer> {
}
